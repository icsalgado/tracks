<?php
	
	$GLOBALS['enderecoInstalacao'] = 'http://seusite.com/';
	
    function conectaBanco(){
		$hostname = 'localhost';
		$username = 'usuario';
		$senha = 'senha';
		$banco = 'banco';
	
		$db = mysql_connect($hostname, $username,$senha);
		$conexao = mysql_select_db($banco, $db);
  		return $conexao;
  	}

	str_replace('/','',$enderecoInstalacao,$GLOBALS['contaBarra']);
	$GLOBALS['contaBarra'] -= 2;

?>