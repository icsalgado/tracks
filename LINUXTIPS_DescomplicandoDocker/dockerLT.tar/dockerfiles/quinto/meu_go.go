package main
import "fmt"

func main() {
	fmt.Println("GIROPOPS STRUGUS GIRUS 2")
}


